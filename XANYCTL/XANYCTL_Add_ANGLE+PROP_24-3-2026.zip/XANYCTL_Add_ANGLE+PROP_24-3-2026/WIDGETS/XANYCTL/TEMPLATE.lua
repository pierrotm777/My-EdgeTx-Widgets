-- XANYCTL - configuration par modèle
-- Renommer ce fichier avec le nom exact du modèle EdgeTX (ex: MODEL011.lua ou "MonPlaneur.lua")
--
-- buttons[i] :
--   label = texte affiché
--   type  = "toggle" ou "momentary"
--
-- title :
--   titre affiché pour l'instance
--
-- prop :
--   label = texte affiché au-dessus du slider (modes +PROP)

local cfg = {}

cfg.instances = {
  [1] = {
    title = "INSTANCE 1",
    buttons = {
      { label="1",  type="toggle" },
      { label="2",  type="toggle" },
      { label="3",  type="toggle" },
      { label="4",  type="toggle" },
      { label="5",  type="toggle" },
      { label="6",  type="toggle" },
      { label="7",  type="toggle" },
      { label="8",  type="toggle" },
      { label="9",  type="toggle" },
      { label="10", type="toggle" },
      { label="11", type="toggle" },
      { label="12", type="toggle" },
      { label="13", type="toggle" },
      { label="14", type="toggle" },
      { label="15", type="toggle" },
      { label="16", type="toggle" },
    },
    prop = { label = "PROP 1" },
  },

  [2] = {
    title = "INSTANCE 2",
    buttons = {
      { label="1",  type="toggle" },
      { label="2",  type="toggle" },
      { label="3",  type="toggle" },
      { label="4",  type="toggle" },
      { label="5",  type="toggle" },
      { label="6",  type="toggle" },
      { label="7",  type="toggle" },
      { label="8",  type="toggle" },
      { label="9",  type="toggle" },
      { label="10", type="toggle" },
      { label="11", type="toggle" },
      { label="12", type="toggle" },
      { label="13", type="toggle" },
      { label="14", type="toggle" },
      { label="15", type="toggle" },
      { label="16", type="toggle" },
    },
    prop = { label = "PROP 2" },
  },

  [3] = {
    title = "INSTANCE 3",
    buttons = {
      { label="1",  type="toggle" },
      { label="2",  type="toggle" },
      { label="3",  type="toggle" },
      { label="4",  type="toggle" },
      { label="5",  type="toggle" },
      { label="6",  type="toggle" },
      { label="7",  type="toggle" },
      { label="8",  type="toggle" },
      { label="9",  type="toggle" },
      { label="10", type="toggle" },
      { label="11", type="toggle" },
      { label="12", type="toggle" },
      { label="13", type="toggle" },
      { label="14", type="toggle" },
      { label="15", type="toggle" },
      { label="16", type="toggle" },
    },
    prop = { label = "PROP 3" },
  },

  [4] = {
    title = "INSTANCE 4",
    buttons = {
      { label="1",  type="toggle" },
      { label="2",  type="toggle" },
      { label="3",  type="toggle" },
      { label="4",  type="toggle" },
      { label="5",  type="toggle" },
      { label="6",  type="toggle" },
      { label="7",  type="toggle" },
      { label="8",  type="toggle" },
      { label="9",  type="toggle" },
      { label="10", type="toggle" },
      { label="11", type="toggle" },
      { label="12", type="toggle" },
      { label="13", type="toggle" },
      { label="14", type="toggle" },
      { label="15", type="toggle" },
      { label="16", type="toggle" },
    },
    prop = { label = "PROP 4" },
  },
}

return cfg