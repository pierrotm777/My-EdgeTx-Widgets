return {
  REQUIRED_VERSION = "ПОТРІБНА ВЕРСІЯ",
  BAD_VERSION = "неправильна конфігурація, використано TEMPLATE",
  NO_LIBGUI_FOUND = "файл libGUI відсутній",
  NO_BUTTONS_FOUND = "файл buttons.lua відсутній",
  NO_CONFIG_FOUND = "%s не знайдено\n%s було додано"
}
