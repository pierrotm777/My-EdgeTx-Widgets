return {
  REQUIRED_VERSION = "erforderlich",
  BAD_VERSION = "ungültige Konfiguration, TEMPLATE verwendet",
  NO_LIBGUI_FOUND = "libGUI-Datei fehlt",
  NO_BUTTONS_FOUND = "buttons.lua-Datei fehlt",
  NO_CONFIG_FOUND = "%s nicht gefunden\n%s wurde hinzugefügt",
}
