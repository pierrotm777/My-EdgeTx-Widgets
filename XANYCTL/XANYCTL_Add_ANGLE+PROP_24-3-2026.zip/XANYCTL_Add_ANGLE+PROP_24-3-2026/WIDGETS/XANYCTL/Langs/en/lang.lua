return {
  REQUIRED_VERSION = "required",
  BAD_VERSION = "invalid config, TEMPLATE used",
  NO_LIBGUI_FOUND = "missing libGUI file",
  NO_BUTTONS_FOUND = "missing buttons.lua file",
  NO_CONFIG_FOUND = "%s not found\n%s has been added",
}
