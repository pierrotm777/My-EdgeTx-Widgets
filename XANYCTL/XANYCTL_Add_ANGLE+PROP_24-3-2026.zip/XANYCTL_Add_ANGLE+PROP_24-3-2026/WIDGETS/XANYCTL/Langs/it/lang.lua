return {
  REQUIRED_VERSION = "richiesta",
  BAD_VERSION = "configurazione non valida, TEMPLATE usato",
  NO_LIBGUI_FOUND = "file libGUI mancante",
  NO_BUTTONS_FOUND = "file buttons.lua mancante",
  NO_CONFIG_FOUND = "%s non trovato\n%s è stato aggiunto",
}
