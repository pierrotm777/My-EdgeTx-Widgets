return {
  REQUIRED_VERSION = "VERSION REQUISE",
  BAD_VERSION = "configuration invalide, TEMPLATE utilisé",
  NO_LIBGUI_FOUND = "fichier libGUI absent",
  NO_BUTTONS_FOUND = "fichier buttons.lua absent",
  NO_CONFIG_FOUND = "%s non trouvé\n%s a été ajouté"
}