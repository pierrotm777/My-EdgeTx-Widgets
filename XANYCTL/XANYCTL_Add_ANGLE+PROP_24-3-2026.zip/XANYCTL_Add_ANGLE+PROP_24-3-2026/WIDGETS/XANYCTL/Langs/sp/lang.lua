return {
  REQUIRED_VERSION = "requerida",
  BAD_VERSION = "configuración no válida, TEMPLATE usado",
  NO_LIBGUI_FOUND = "falta el archivo libGUI",
  NO_BUTTONS_FOUND = "falta el archivo buttons.lua",
  NO_CONFIG_FOUND = "%s no encontrado\n%s se agrega",
}
