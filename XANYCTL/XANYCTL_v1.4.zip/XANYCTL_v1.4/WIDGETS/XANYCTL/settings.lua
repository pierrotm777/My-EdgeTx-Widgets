-- XANYCTL - settings.lua
-- Ecran prototype de réglage pour TEST.lua
-- Version ajustée après retour utilisateur :
--   - textes remontés
--   - tailles un peu réduites
--   - barre message plus basse et avec texte visible
--   - panneau bas descendu pour mieux dégager le centre
--   - ajout d'un sélecteur de logos depuis /WIDGETS/XANYCTL/Logos/

local APP_NAME = "XANYCTL EDIT"
local APP_VER  = "v1.4"

local TXT_DEFAULT = {
  SETTINGS_MODEL = "Modèle: ",
  SETTINGS_INSTANCE = "INSTANCE",
  SETTINGS_BUTTON = "BOUTON",
  SETTINGS_TYPE = "Type",
  SETTINGS_TITLE = "Titre",
  SETTINGS_SLIDER = "Curseur",
  SETTINGS_SAVE = "Sauver",
  SETTINGS_LOGO = "SELECTION LOGO",
}

local TXT = {}
for k, v in pairs(TXT_DEFAULT) do
  TXT[k] = v
end
local loadedLanguageCode = nil

local function T(k, fallback)
  local v = TXT[k]
  if v == nil or v == "" then
    return fallback
  end
  return v
end

local function getLanguageCode()
  local ctx = _G and _G.XANYCTL_SETTINGS_CONTEXT
  local opts = ctx and ctx.options
  local idx = (opts and opts.Language) or 4
  local langs = { "cn", "de", "en", "fr", "it", "sp", "ua" }
  return langs[idx] or "fr"
end

local function loadLanguageTexts(force)
  local langCode = getLanguageCode()

  if not force and loadedLanguageCode == langCode then
    return
  end
  loadedLanguageCode = langCode

  for k, v in pairs(TXT_DEFAULT) do
    TXT[k] = v
  end

  local path = "/WIDGETS/XANYCTL/Langs/" .. langCode .. "/lang.lua"
  local chunk = loadScript(path)
  if not chunk then
    return
  end

  local ok, result = pcall(chunk)
  if not ok or type(result) ~= "table" then
    return
  end

  for k, v in pairs(result) do
    if type(v) == "string" then
      TXT[k] = v
    end
  end
end

local headerBitmap = false
local pickerPreviewPath = nil
local pickerPreviewBitmap = nil
local drawHeader
local getModelName

local editor = {
  instanceId = 1,
  buttonIndex = 1,
  cfg = nil,
  logoCache = {},
  touchRects = {},
  message = nil,
  messageUntil = 0,
  logoPickerOpen = false,
  logoList = {},
  logoIndex = 1,
  logoScroll = 1,
  textEditActive = false,
  textEditBuffer = "",
  textEditTarget = nil,
  textEditShift = false,
  textEditMaxLen = 20,
}

local COLORS = {
  panel = DARKGREY,
  panel2 = GREY,
  button = GREY,
  zone = DARKGREEN,
  border = WHITE,
  text = WHITE,
  accent = YELLOW,
  pickerSel = DARKGREEN,
}

local function showMessage(txt, ticks)
  editor.message = txt
  editor.messageUntil = getTime() + (ticks or 120)
end

local function getConfigPath()
  return "/WIDGETS/XANYCTL/TEST.lua"
end

getModelName = function()
  local mi = model.getInfo()
  return (mi and mi.name) or "MODELE"
end

local function getConfigDisplayName()
  return getModelName() .. ".lua"
end

local function drawFilledRect(x, y, w, h, color)
  lcd.setColor(CUSTOM_COLOR, color)
  if lcd.drawFilledRectangle then
    lcd.drawFilledRectangle(x, y, w, h, CUSTOM_COLOR)
  end
end

local function drawPanel(x, y, w, h, bg, border)
  drawFilledRect(x, y, w, h, bg)
  if lcd.drawRectangle then
    lcd.setColor(CUSTOM_COLOR, border or COLORS.border)
    lcd.drawRectangle(x, y, w, h, CUSTOM_COLOR)
  end
end

local function drawTextC(x, y, txt, flags)
  lcd.drawText(x, y, txt or "", (flags or 0) + CENTER + WHITE)
end

local function setRect(name, x, y, w, h)
  editor.touchRects[name] = { x = x, y = y, w = w, h = h }
end

local function hitRect(name, tx, ty)
  local r = editor.touchRects[name]
  if not r then return false end
  return tx >= r.x and tx <= (r.x + r.w) and ty >= r.y and ty <= (r.y + r.h)
end

local function normalizeButton(btn, idx)
  btn = btn or {}
  if type(btn.label) ~= "string" then btn.label = tostring(idx) end
  if btn.type ~= "momentary" then btn.type = "toggle" end
  if type(btn.logo) ~= "string" then btn.logo = "" end
  return btn
end

local function ensureConfig()
  editor.cfg = editor.cfg or {}
  editor.cfg.instances = editor.cfg.instances or {}

  for instId = 1, 4 do
    local inst = editor.cfg.instances[instId]
    if type(inst) ~= "table" then
      inst = {
        title = "INSTANCE " .. tostring(instId),
        buttons = {},
        prop = { label = "PROP", logo = "" },
      }
      editor.cfg.instances[instId] = inst
    end

    if type(inst.title) ~= "string" or inst.title == "" then
      inst.title = "INSTANCE " .. tostring(instId)
    end

    inst.buttons = inst.buttons or {}
    for i = 1, 16 do
      inst.buttons[i] = normalizeButton(inst.buttons[i], i)
    end

    inst.prop = inst.prop or { label = "PROP", logo = "" }
    if type(inst.prop.label) ~= "string" or inst.prop.label == "" then
      inst.prop.label = "PROP"
    end
    if type(inst.prop.logo) ~= "string" then
      inst.prop.logo = ""
    end
  end
end

local function loadConfig()
  local path = getConfigPath()
  local chunk = loadScript(path)

  if not chunk then
    editor.cfg = nil
    showMessage(getConfigDisplayName() .. " absent ou invalide", 200)
    return false
  end

  local ok, cfg = pcall(chunk)
  if not ok or type(cfg) ~= "table" then
    editor.cfg = nil
    showMessage(getConfigDisplayName() .. " invalide", 200)
    return false
  end

  editor.cfg = cfg
  ensureConfig()
  return true
end

local function getInstance()
  ensureConfig()
  return editor.cfg.instances[editor.instanceId]
end

local function getButton()
  local inst = getInstance()
  return inst.buttons[editor.buttonIndex], inst
end

local function getLogoPath(name)
  if not name or name == "" then return nil end
  if string.sub(name, 1, 1) == "/" then return name end
  return "/WIDGETS/XANYCTL/Logos/" .. name
end

local function loadBitmap(path)
  if not path or path == "" then return nil end
  if editor.logoCache[path] ~= nil then return editor.logoCache[path] end

  local bmp = nil
  if Bitmap and type(Bitmap.open) == "function" then
    local ok, img = pcall(Bitmap.open, path)
    if ok then bmp = img end
  end
  if not bmp and lcd and type(lcd.loadBitmap) == "function" then
    local ok, img = pcall(lcd.loadBitmap, path)
    if ok then bmp = img end
  end

  editor.logoCache[path] = bmp
  return bmp
end

local function loadPickerPreviewBitmap(path)
  if not path or path == "" then
    pickerPreviewPath = nil
    pickerPreviewBitmap = nil
    return nil
  end

  if pickerPreviewPath == path and pickerPreviewBitmap ~= nil then
    return pickerPreviewBitmap
  end

  pickerPreviewPath = path
  pickerPreviewBitmap = nil

  local bmp = nil
  if Bitmap and type(Bitmap.open) == "function" then
    local ok, img = pcall(Bitmap.open, path)
    if ok then bmp = img end
  end
  if not bmp and lcd and type(lcd.loadBitmap) == "function" then
    local ok, img = pcall(lcd.loadBitmap, path)
    if ok then bmp = img end
  end

  pickerPreviewBitmap = bmp
  return pickerPreviewBitmap
end

local function loadLogoList()
  editor.logoList = { "" }

  local added = { [""] = true }

  if dir then
    local ok, iter = pcall(dir, "/WIDGETS/XANYCTL/Logos")
    if ok and iter then
      for name in iter do
        if type(name) == "string" then
          local lower = string.lower(name)
          if string.sub(lower, -4) == ".png" and not added[name] then
            editor.logoList[#editor.logoList + 1] = name
            added[name] = true
          end
        end
      end
    end
  end

  table.sort(editor.logoList, function(a, b)
    if a == "" then return true end
    if b == "" then return false end
    return string.lower(a) < string.lower(b)
  end)

  local btn = getButton()
  local current = btn and btn.logo or ""
  editor.logoIndex = 1
  for i = 1, #editor.logoList do
    if editor.logoList[i] == current then
      editor.logoIndex = i
      break
    end
  end
  editor.logoScroll = math.max(1, editor.logoIndex - 3)
end

local function keepLogoSelectionVisible()
  if editor.logoIndex < editor.logoScroll then
    editor.logoScroll = editor.logoIndex
  end
  local maxVisible = 8
  if editor.logoIndex > editor.logoScroll + maxVisible - 1 then
    editor.logoScroll = editor.logoIndex - maxVisible + 1
  end
  if editor.logoScroll < 1 then editor.logoScroll = 1 end
end

local function openLogoPicker()
  loadLogoList()
  editor.logoPickerOpen = true
end

local function closeLogoPicker()
  editor.logoPickerOpen = false
end

local function applySelectedLogo()
  local btn = getButton()
  local selected = editor.logoList[editor.logoIndex] or ""
  btn.logo = selected
  showMessage((selected ~= "" and selected) or "Logo efface", 120)
  closeLogoPicker()
end


local KEYBOARD_LAYOUT = nil
local loadedKeyboardCode = nil

local function loadKeyboardLayout(force)
  local langCode = getLanguageCode()

  if not force and loadedKeyboardCode == langCode and KEYBOARD_LAYOUT then
    return
  end
  loadedKeyboardCode = langCode

  local path = "/WIDGETS/XANYCTL/Langs/" .. langCode .. "/keyboard.lua"
  local chunk = loadScript(path)

  if chunk then
    local ok, result = pcall(chunk)
    if ok and type(result) == "table" and type(result.rows) == "table" then
      KEYBOARD_LAYOUT = result.rows
      return
    end
  end

  KEYBOARD_LAYOUT = {
    { "a","b","c","d","e","f","g","h" },
    { "i","j","k","l","m","n","o","p" },
    { "q","r","s","t","u","v","w","x" },
    { "y","z","0","1","2","3","4","5" },
    { "6","7","8","9","-","_","/","." },
    { "SPACE","EFF","SHIFT","OK","ANN" },
  }
end

local function beginTextEdit(targetType, currentText)
  editor.textEditActive = true
  editor.textEditBuffer = tostring(currentText or "")
  editor.textEditTarget = targetType
  editor.textEditShift = false
end

local function cancelTextEdit()
  editor.textEditActive = false
  editor.textEditBuffer = ""
  editor.textEditTarget = nil
  editor.textEditShift = false
end

local function applyTextEdit()
  ensureConfig()

  local btn, inst = getButton()
  local txt = tostring(editor.textEditBuffer or "")

  if editor.textEditTarget == "label" then
    btn.label = txt
  elseif editor.textEditTarget == "title" then
    inst.title = txt
  elseif editor.textEditTarget == "slider" then
    inst.prop = inst.prop or { label = "PROP", logo = "" }
    inst.prop.label = txt
  end

  cancelTextEdit()
end

local function appendTextChar(ch)
  local s = tostring(editor.textEditBuffer or "")
  if string.len(s) >= (editor.textEditMaxLen or 20) then
    return
  end
  editor.textEditBuffer = s .. tostring(ch or "")
end

local function backspaceTextChar()
  local s = tostring(editor.textEditBuffer or "")
  local len = string.len(s)
  if len <= 0 then
    return
  end
  editor.textEditBuffer = string.sub(s, 1, len - 1)
end

local function handleTextEditKey(key)
  if key == "SHIFT" then
    editor.textEditShift = not editor.textEditShift
    return
  end
  if key == "EFF" then
    backspaceTextChar()
    return
  end
  if key == "SPACE" then
    appendTextChar(" ")
    return
  end
  if key == "OK" then
    applyTextEdit()
    return
  end
  if key == "ANN" then
    cancelTextEdit()
    return
  end

  local ch = tostring(key or "")
  if string.len(ch) == 1 then
    if editor.textEditShift then
      ch = string.upper(ch)
    end
    appendTextChar(ch)
  else
    appendTextChar(ch)
  end
end

local function drawTextEditor()
  editor.touchRects = {}

  lcd.clear()
  drawHeader()

  drawPanel(8, 52, 464, 212, COLORS.panel2, COLORS.border)

  local title = "EDIT"
  if editor.textEditTarget == "label" then
    title = "LABEL"
  elseif editor.textEditTarget == "title" then
    title = T("SETTINGS_TITLE", "Titre")
  elseif editor.textEditTarget == "slider" then
    title = T("SETTINGS_SLIDER", "Curseur")
  end

  lcd.drawText(20, 60, title, MIDSIZE + WHITE + SHADOWED)

  drawPanel(20, 60, 240, 30, COLORS.panel, COLORS.border)
  lcd.drawText(28, 61, editor.textEditBuffer or "", MIDSIZE + WHITE + SHADOWED)

  local info = editor.textEditShift and "SHIFT ON" or "SHIFT OFF"
  lcd.drawText(270, 67, info, SMLSIZE + WHITE + SHADOWED)

  local startX = 20
  local startY = 100
  local keyH = 18
  local rowGap = 6
  local keyGap = 4

  for r = 1, #KEYBOARD_LAYOUT do
    local row = KEYBOARD_LAYOUT[r]
    local y = startY + (r - 1) * (keyH + rowGap)
    local x = startX

    if r == #KEYBOARD_LAYOUT then
      local widths = { 82, 58, 82, 58, 58 }
      for c = 1, #row do
        local key = row[c]
        local w = widths[c] or 50
        drawPanel(x, y, w, keyH, COLORS.panel, COLORS.border)
        drawTextC(x + math.floor(w / 2), y + 3, key, SMLSIZE + SHADOWED)
        setRect("kb_" .. tostring(r) .. "_" .. tostring(c), x, y, w, keyH)
        x = x + w + keyGap
      end
    else
      local w = 50
      for c = 1, #row do
        local key = row[c]
        local display = key
        if string.len(display) == 1 and editor.textEditShift then
          display = string.upper(display)
        end
        drawPanel(x, y, w, keyH, COLORS.panel, COLORS.border)
        drawTextC(x + math.floor(w / 2), y + 3, display, SMLSIZE + SHADOWED)
        setRect("kb_" .. tostring(r) .. "_" .. tostring(c), x, y, w, keyH)
        x = x + w + keyGap
      end
    end
  end
end

local function handleTextEditorTouch(tx, ty)
  for r = 1, #KEYBOARD_LAYOUT do
    local row = KEYBOARD_LAYOUT[r]
    for c = 1, #row do
      local name = "kb_" .. tostring(r) .. "_" .. tostring(c)
      if hitRect(name, tx, ty) then
        handleTextEditKey(row[c])
        return
      end
    end
  end
end

local function escapeString(s)
  s = tostring(s or "")
  s = string.gsub(s, "\\", "\\\\")
  s = string.gsub(s, "\n", "\\n")
  s = string.gsub(s, "\r", "\\r")
  s = string.gsub(s, "\"", "\\\"")
  return s
end

local function buildConfigContent(cfg)
  local lines = {}

  lines[#lines + 1] = "local cfg = {}"
  lines[#lines + 1] = ""
  lines[#lines + 1] = "cfg.instances = {"

  local instances = (cfg and cfg.instances) or {}

  for instId = 1, 4 do
    local inst = instances[instId] or {}
    local buttons = inst.buttons or {}
    local prop = inst.prop or {}

    lines[#lines + 1] = "  [" .. instId .. "] = {"
    lines[#lines + 1] = "    title = \"" .. escapeString(inst.title or ("INSTANCE " .. tostring(instId))) .. "\","
    lines[#lines + 1] = "    buttons = {"

    for i = 1, 16 do
      local b = normalizeButton(buttons[i], i)
      local label = escapeString(b.label or tostring(i))
      local typ = escapeString(b.type or "toggle")
      local logo = escapeString(b.logo or "")
      lines[#lines + 1] = "      { label=\"" .. label .. "\",  type=\"" .. typ .. "\",    logo=\"" .. logo .. "\" },"
    end

    lines[#lines + 1] = "    },"
    lines[#lines + 1] = "    prop = { label = \"" .. escapeString(prop.label or ("PROP " .. tostring(instId))) .. "\", logo=\"" .. escapeString(prop.logo or "") .. "\" },"
    lines[#lines + 1] = "  },"
    lines[#lines + 1] = ""
  end

  lines[#lines + 1] = "}"
  lines[#lines + 1] = ""
  lines[#lines + 1] = "return cfg"

  return table.concat(lines, "\n")
end

local function saveConfig()
  if not editor.cfg then
    showMessage("Rien a sauver", 120)
    return false
  end

  ensureConfig()

  local content = buildConfigContent(editor.cfg)
  if not content or content == "" then
    showMessage("Contenu vide", 160)
    return false
  end

  local path = getConfigPath()
  local f = io and io.open and io.open(path, "w")
  if not f then
    showMessage("Echec ouverture " .. getConfigDisplayName(), 160)
    return false
  end

  local ok = false
  if io and io.write then
    ok = pcall(io.write, f, content)
  elseif f and f.write then
    ok = pcall(f.write, f, content)
  end

  if io and io.close then
    pcall(io.close, f)
  elseif f and f.close then
    pcall(f.close, f)
  end

  if not ok then
    showMessage("Erreur sauvegarde", 160)
    return false
  end

  showMessage(getConfigDisplayName() .. " sauvegarde", 140)
  return true
end

local function loadHeaderBitmap()
  if headerBitmap ~= false then
    return headerBitmap
  end

  headerBitmap = nil

  if Bitmap and type(Bitmap.open) == "function" then
    local ok, img = pcall(Bitmap.open, "/WIDGETS/XANYCTL/Images/RCUL30x39.png")
    if ok then headerBitmap = img end
  end

  if not headerBitmap and lcd and type(lcd.loadBitmap) == "function" then
    local ok, img = pcall(lcd.loadBitmap, "/WIDGETS/XANYCTL/Images/RCUL30x39.png")
    if ok then headerBitmap = img end
  end

  return headerBitmap
end

drawHeader = function()
  drawPanel(0, 0, 480, 48, COLORS.panel, COLORS.border)

  local bmp = loadHeaderBitmap()
  if bmp then
    lcd.drawBitmap(bmp, 4, 2)
  end

  lcd.drawText(40, 8, APP_NAME, MIDSIZE + RED + SHADOWED)
  lcd.drawText(450, 20, APP_VER, SMLSIZE + WHITE + SHADOWED)
  lcd.drawText(215, 8, T("SETTINGS_MODEL", "Modèle: ") .. getModelName(), MIDSIZE + WHITE + SHADOWED)
end

local function drawNavButton(name, x, y, w, h, txt, sub)
  drawPanel(x, y, w, h, COLORS.panel, COLORS.border)
  drawTextC(x + math.floor(w / 2), y + 0, txt, MIDSIZE + SHADOWED)
  if sub and sub ~= "" then
    drawTextC(x + math.floor(w / 2), y + h - 14, sub, SMLSIZE + SHADOWED)
  end
  setRect(name, x, y, w, h)
end

local function drawAction(name, x, y, w, h, title, value)
  drawPanel(x, y, w, h, COLORS.panel, COLORS.border)
  drawTextC(x + math.floor(w / 2), y + 0, title, MIDSIZE + SHADOWED)
  if value and value ~= "" then
    drawTextC(x + math.floor(w / 2), y + 24, value, SMLSIZE + SHADOWED)
  end
  setRect(name, x, y, w, h)
end

local function drawLeftPanel()
  local px = 362
  drawPanel(px, 44, 112, 218, COLORS.panel2, COLORS.border)

  lcd.drawText(px + 10, 52, T("SETTINGS_INSTANCE", "INSTANCE"), SMLSIZE + WHITE + SHADOWED)
  drawPanel(px + 8, 68, 96, 34, COLORS.panel, COLORS.border)
  drawTextC(px + 56, 66, tostring(editor.instanceId), DBLSIZE + SHADOWED)
  setRect("instance_box", px + 8, 68, 96, 34)

  drawNavButton("inst_prev", px + 8, 108, 44, 34, "-", "")
  drawNavButton("inst_next", px + 60, 108, 44, 34, "+", "")

  lcd.drawText(px + 10, 152, T("SETTINGS_BUTTON", "BOUTON"), SMLSIZE + WHITE + SHADOWED)
  drawPanel(px + 8, 168, 96, 34, COLORS.panel, COLORS.border)
  drawTextC(px + 56, 166, tostring(editor.buttonIndex), DBLSIZE + SHADOWED)

  drawNavButton("btn_prev", px + 8, 208, 44, 34, "-", "")
  drawNavButton("btn_next", px + 60, 208, 44, 34, "+", "")
end

local function drawLogoPreview(px, py, pw, logoName)
  local zx = px + 14
  local zy = py + 12 + 45
  local zw = pw - 28
  local zh = 90
  local bmp = loadBitmap(getLogoPath(logoName))

  drawPanel(zx, zy, zw, zh, COLORS.zone, COLORS.border)
  lcd.drawText(zx + 8, zy - 15, "LOGO", SMLSIZE + WHITE)

  if bmp then
    local drawX = zx + math.floor(zw / 2) - 20
    local drawY = zy + 18
    local ok = pcall(function() lcd.drawBitmap(bmp, drawX, drawY, 60) end)
    if not ok then ok = pcall(function() lcd.drawBitmap(drawX, drawY, bmp, 60) end) end
    if not ok then ok = pcall(function() lcd.drawBitmap(bmp, drawX, drawY) end) end
    if not ok then pcall(function() lcd.drawBitmap(drawX, drawY, bmp) end) end
  else
    drawTextC(zx + math.floor(zw / 2), zy + 30, (logoName ~= "" and logoName) or "aucun logo", SMLSIZE)
    drawTextC(zx + math.floor(zw / 2), zy + 46, "/Logos/*.png", SMLSIZE)
  end

  setRect("logo_zone", zx, zy, zw, zh)
end

local function drawLabelPreview(px, py, pw, ph, label)
  local zx = px + 14
  local zh = 40
  local zy = py + ph - zh - 12
  local zw = pw - 28

  drawPanel(zx, zy, zw, zh, COLORS.zone, COLORS.border)
  lcd.drawText(zx + 8, zy - 15, "LABEL", SMLSIZE + WHITE)
  drawTextC(zx + math.floor(zw / 2), zy + 8, label or "", MIDSIZE)
  setRect("label_zone", zx, zy, zw, zh)
end

local function drawCenterPanel(btn)
  local px, py, pw, ph = 126, 44, 228, 218
  drawPanel(px, py, pw, ph, COLORS.panel2, COLORS.border)
  drawTextC(px + math.floor(pw / 2), py + 8, T("SETTINGS_BUTTON", "BOUTON") .. " " .. tostring(editor.buttonIndex), MIDSIZE + SHADOWED)

  drawLogoPreview(px, py, pw, btn.logo or "")
  drawLabelPreview(px, py, pw, ph, btn.label or "")
  setRect("preview_button", px, py, pw, ph)
end

local function drawRightPanel(btn, inst)
  local px = 6
  drawPanel(px, 44, 112, 218, COLORS.panel2, COLORS.border)

  drawAction("type_box", px + 8, 50, 96, 42, T("SETTINGS_TYPE", "Type"), tostring(btn.type or "toggle"))
  drawAction("title_box", px + 8, 100, 96, 42, T("SETTINGS_TITLE", "Titre"), tostring(inst.title or ""))
  drawAction("prop_box", px + 8, 150, 96, 42, T("SETTINGS_SLIDER", "Curseur"), tostring((inst.prop and inst.prop.label) or "PROP"))
  drawAction("save_box", px + 8, 200, 96, 42, T("SETTINGS_SAVE", "Sauver"), "placeholder")
end

local function drawBottomBar(btn)
  local y = 276
  drawAction("edit_logo", 126, y, 110, 34, "Logo", (btn.logo ~= "" and btn.logo) or "choisir")
  drawAction("edit_label", 243, y, 111, 34, "Label", (btn.label ~= "" and btn.label) or "saisir")
  drawAction("help_box", 362, y, 112, 34, "Aide", "actions")

  lcd.drawText(8, 278, "Appui logo: choix image", SMLSIZE + WHITE)
  lcd.drawText(8, 292, "Appui label: clavier EdgeTX", SMLSIZE + WHITE)
end

local function drawOverlayMessage()
  if not editor.message or getTime() >= editor.messageUntil then
    return
  end

  local w, h = 320, 30
  local x = math.floor((480 - w) / 2)
  local y = 228
  drawPanel(x, y, w, h, BLACK, YELLOW)
  drawTextC(x + math.floor(w / 2), y + 7, editor.message, SMLSIZE)
end

local function drawLogoPicker()
  lcd.clear()
  drawHeader()

  drawPanel(16, 56, 448, 200, COLORS.panel2, COLORS.border)
  lcd.drawText(28, 60, T("SETTINGS_LOGO", "SELECTION LOGO"), MIDSIZE + WHITE + SHADOWED)
  lcd.drawText(28, 86, "Dossier: /WIDGETS/XANYCTL/Logos/", SMLSIZE + WHITE + SHADOWED)

  local previewName = editor.logoList[editor.logoIndex] or ""
  drawPanel(298, 96, 150, 112, COLORS.panel, COLORS.border)
  lcd.drawText(308, 104, "APERÇU", SMLSIZE + WHITE)
  if previewName == "" then
    drawTextC(373, 150, "aucun", MIDSIZE)
  else
    local bmp = loadPickerPreviewBitmap(getLogoPath(previewName))
    if bmp then
      local drawX = 373 - 16
      local drawY = 126
      local ok = pcall(function() lcd.drawBitmap(bmp, drawX, drawY) end)
      if not ok then ok = pcall(function() lcd.drawBitmap(drawX, drawY, bmp) end) end
      if not ok then
        drawTextC(373, 150, previewName, SMLSIZE)
      end
    else
      drawTextC(373, 150, previewName, SMLSIZE)
    end
  end

  local startX = 28
  local startY = 100
  local rowH = 18
  local maxVisible = 8
  keepLogoSelectionVisible()

  for row = 0, maxVisible - 1 do
    local i = editor.logoScroll + row
    if i > #editor.logoList then break end
    local y = startY + row * rowH
    local name = editor.logoList[i]
    if i == editor.logoIndex then
      drawPanel(startX - 4, y - 1, 250, 16, COLORS.pickerSel, COLORS.accent)
    end
    lcd.drawText(startX, y, (name ~= "" and name) or "<aucun>", SMLSIZE + WHITE)
    setRect("logo_pick_" .. tostring(i), startX - 4, y - 1, 250, 16)
  end

  drawPanel(16, 262, 448, 34, COLORS.panel, COLORS.border)
  lcd.drawText(28, 272, "+/- ou ROT : deplacer", SMLSIZE + WHITE)
  lcd.drawText(196, 272, "ENT : valider", SMLSIZE + WHITE)
  lcd.drawText(324, 272, "RET : retour", SMLSIZE + WHITE)
end

local function cycleInstance(step)
  editor.instanceId = editor.instanceId + step
  if editor.instanceId < 1 then editor.instanceId = 4 end
  if editor.instanceId > 4 then editor.instanceId = 1 end
  showMessage("Instance " .. tostring(editor.instanceId), 70)
end

local function cycleButton(step)
  editor.buttonIndex = editor.buttonIndex + step
  if editor.buttonIndex < 1 then editor.buttonIndex = 16 end
  if editor.buttonIndex > 16 then editor.buttonIndex = 1 end
  showMessage("Bouton " .. tostring(editor.buttonIndex), 70)
end

local function cycleType(btn)
  if (btn.type or "toggle") == "toggle" then
    btn.type = "momentary"
  else
    btn.type = "toggle"
  end
  showMessage("Type: " .. tostring(btn.type), 90)
end

local function requestLogoEdit()
  openLogoPicker()
end

local function requestLabelEdit()
  local btn = getButton()
  beginTextEdit("label", btn and btn.label or "")
end

local function requestTitleEdit()
  local inst = getInstance()
  beginTextEdit("title", inst and inst.title or "")
end

local function requestPropEdit()
  local inst = getInstance()
  beginTextEdit("slider", (inst and inst.prop and inst.prop.label) or "PROP")
end

local function requestHelp()
  showMessage("Logo, Label, Type, Titre, Slider, puis sauvegarde " .. getConfigDisplayName(), 150)
end

local function savePlaceholder()
  saveConfig()
end

local function handleTouch(tx, ty, btn, inst)
  if hitRect("logo_zone", tx, ty) or hitRect("edit_logo", tx, ty) then
    requestLogoEdit(btn)
    return
  elseif hitRect("label_zone", tx, ty) or hitRect("edit_label", tx, ty) then
    requestLabelEdit(btn)
    return
  end

  if hitRect("inst_prev", tx, ty) then
    cycleInstance(-1)
  elseif hitRect("inst_next", tx, ty) or hitRect("instance_box", tx, ty) then
    cycleInstance(1)
  elseif hitRect("btn_prev", tx, ty) then
    cycleButton(-1)
  elseif hitRect("btn_next", tx, ty) or hitRect("preview_button", tx, ty) then
    cycleButton(1)
  elseif hitRect("type_box", tx, ty) then
    cycleType(btn)
  elseif hitRect("title_box", tx, ty) then
    requestTitleEdit(inst)
  elseif hitRect("prop_box", tx, ty) then
    requestPropEdit(inst)
  elseif hitRect("save_box", tx, ty) then
    savePlaceholder()
  elseif hitRect("help_box", tx, ty) then
    requestHelp()
  end
end

local function handleLogoPickerTouch(tx, ty)
  for i = 1, #editor.logoList do
    if hitRect("logo_pick_" .. tostring(i), tx, ty) then
      editor.logoIndex = i
      applySelectedLogo()
      return
    end
  end
end

local function redraw()
  loadLanguageTexts(false)
  loadKeyboardLayout(false)

  if not editor.cfg then
    loadConfig()
  end

  ensureConfig()
  local btn, inst = getButton()
  editor.touchRects = {}

  lcd.clear()
  drawHeader()
  drawLeftPanel()
  drawCenterPanel(btn)
  drawRightPanel(btn, inst)
  drawBottomBar(btn)
  drawOverlayMessage()
end

local function runLogoPicker(event, touchState)
  editor.touchRects = {}
  drawLogoPicker()

  if event == EVT_VIRTUAL_NEXT or event == EVT_PLUS_BREAK or event == EVT_ROT_RIGHT then
    editor.logoIndex = editor.logoIndex + 1
    if editor.logoIndex > #editor.logoList then editor.logoIndex = 1 end
  elseif event == EVT_VIRTUAL_PREV or event == EVT_MINUS_BREAK or event == EVT_ROT_LEFT then
    editor.logoIndex = editor.logoIndex - 1
    if editor.logoIndex < 1 then editor.logoIndex = #editor.logoList end
  elseif event == EVT_ENTER_BREAK then
    applySelectedLogo()
  elseif event == EVT_EXIT_BREAK then
    closeLogoPicker()
  elseif event == EVT_TOUCH_FIRST and touchState then
    handleLogoPickerTouch(touchState.x, touchState.y)
  end
end

local function run(event, touchState)
  if editor.logoPickerOpen then
    runLogoPicker(event, touchState)
    return
  end

  if editor.textEditActive then
    loadKeyboardLayout(false)
    drawTextEditor()

    if event == EVT_EXIT_BREAK then
      cancelTextEdit()
      return
    elseif event == EVT_TOUCH_FIRST and touchState then
      handleTextEditorTouch(touchState.x, touchState.y)
      return
    end

    return
  end

  redraw()

  local btn, inst = getButton()

  if event == EVT_VIRTUAL_NEXT or event == EVT_PLUS_BREAK or event == EVT_ROT_RIGHT then
    cycleButton(1)
  elseif event == EVT_VIRTUAL_PREV or event == EVT_MINUS_BREAK or event == EVT_ROT_LEFT then
    cycleButton(-1)
  elseif event == EVT_ENTER_BREAK then
    requestLabelEdit(btn)
  elseif event == EVT_MENU_BREAK or event == EVT_LONG_ENTER then
    savePlaceholder()
  elseif event == EVT_TOUCH_FIRST and touchState then
    handleTouch(touchState.x, touchState.y, btn, inst)
  end
end

local function init()
  loadLanguageTexts(true)
  loadKeyboardLayout(true)
  loadConfig()
end

return {
  init = init,
  run = run,
}
