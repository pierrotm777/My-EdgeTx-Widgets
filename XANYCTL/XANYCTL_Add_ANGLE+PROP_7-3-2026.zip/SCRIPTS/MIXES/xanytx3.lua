-- xanytx3.lua - XANY FM-bank wrapper
-- ID=3 -> FM2
FM_INDEX = 2
return loadScript("/SCRIPTS/MIXES/xanytx_common.lua")()
