-- xanytx1.lua - XANY FM-bank wrapper
-- ID=1 -> FM0
FM_INDEX = 0
return loadScript("/SCRIPTS/MIXES/xanytx_common.lua")()
