-- xanytx4.lua - XANY FM-bank wrapper
-- ID=4 -> FM3
FM_INDEX = 3
return loadScript("/SCRIPTS/MIXES/xanytx_common.lua")()
