XANYCTL (SW8) - Widget EdgeTX + LibGUI

Installation (SD de la radio) :
1) Copier le dossier WIDGETS/XANYCTL/ sur la carte SD :
   /WIDGETS/XANYCTL/main.lua
   /WIDGETS/XANYCTL/buttons.lua
   /WIDGETS/XANYCTL/MODEL_TEMPLATE.lua

2) Vérifier que LibGUI est présent :
   /WIDGETS/LibGUI/libgui.lua  (ou libgui.luac)

3) Créer un fichier de configuration spécifique à TON modèle :
   - Renommer MODEL_TEMPLATE.lua en <NomDuModele>.lua
   - Exemple : si ton modèle s'appelle MODEL011 :
       /WIDGETS/XANYCTL/MODEL011.lua

4) Dans EdgeTX :
   - Placer le widget "XANYCTL" sur un écran.
   - Régler les options : MODE / CH / Repeat

Notes :
- Ce widget écrit uniquement des GVars (GV1..GV6) du modèle.
- Le script mix (xanytx.lua) doit lire ces GVars pour produire le signal Xany/RCUL sur une voie.
