--[[
#######################################################################################
#   EspNow : Usable with Wireless Trainer system                                      #
#   Tiny widget which reads channel 8 carrying ESPNOW link state + RSSI.             #
#   Sound alarms are selected automatically from the chosen language folder.          #
#######################################################################################
--]]

local Languages = { "cn", "de", "en", "fr", "it", "sp", "ua" }

local options = {
  { "TextColor", COLOR, WHITE },
  { "RssiCh", SOURCE, 0 },

  -- Seuils optimisés RC (robustesse + marge radio)
  { "GreenThr", VALUE, -75, -95, -45 },
  { "OrangeThr", VALUE, -85, -95, -45 },

  -- Répétition plus rapide (sécurité)
  { "AlarmSec", VALUE, 5, 0, 30 },

  -- Langue
  { "Language", CHOICE, 4, Languages },-- fr by default
}

local function getLanguageCode(wgt)
  local idx = wgt.options.Language or 4
  if idx < 1 then idx = 1 end
  if idx > #Languages then idx = #Languages end
  return Languages[idx]
end

local function getSoundBasePath(wgt)
  return "/WIDGETS/EspNow/Langs/" .. getLanguageCode(wgt) .. "/"
end

local function getAlarmSoundPath(wgt, level)
  local base = getSoundBasePath(wgt)
  if level == 1 then
    return base .. "orange.wav"
  elseif level == 2 then
    return base .. "red.wav"
  end
  return nil
end

local function create(zone, options)
  local wgt = {
    zone = zone,
    options = options,
    lastAlarmTick = 0,
    lastAlarmLevel = 0,
  }
  return wgt
end

local function update(wgt, options)
  if wgt == nil then
    return
  end
  wgt.options = options
end

local function background(wgt)
  return
end

local function clamp(v, vmin, vmax)
  if v < vmin then return vmin end
  if v > vmax then return vmax end
  return v
end

local function rawToUs(raw)
  raw = clamp(raw or 0, -1024, 1024)
  return 1000 + math.floor(((raw + 1024) * 1000) / 2048 + 0.5)
end

local function decodeLinkData(wgt)
  local raw = getValue(wgt.options.RssiCh)
  local us = rawToUs(raw)

  if us < 1300 then
    return raw, us, false, nil
  end

  local rssi = -95 + math.floor(((us - 1300) * 50) / 700 + 0.5)
  rssi = clamp(rssi, -95, -45)
  return raw, us, true, rssi
end

local function getThresholds(wgt)
  local greenThr = wgt.options.GreenThr or -70
  local yellowThr = wgt.options.OrangeThr or -80

  if greenThr < yellowThr then
    local t = greenThr
    greenThr = yellowThr
    yellowThr = t
  end

  return greenThr, yellowThr
end

local function getAlarmLevel(wgt, connected, rssi)
  if not connected or rssi == nil then
    return -1
  end

  local greenThr, yellowThr = getThresholds(wgt)

  if rssi >= greenThr then
    return 0
  elseif rssi >= yellowThr then
    return 1
  else
    return 2
  end
end

local function getBgColor(wgt, connected, rssi)
  local level = getAlarmLevel(wgt, connected, rssi)
  if level == 0 then
    return GREEN
  elseif level == 1 then
    return YELLOW
  else
    return RED
  end
end

local function getLevelLabel(level)
  if level == 0 then
    return "VERT"
  elseif level == 1 then
    return "YELLOW"
  elseif level == 2 then
    return "ROUGE"
  else
    return "CONNECTING"
  end
end

local function handleAlarm(wgt, connected, rssi)
  local level = getAlarmLevel(wgt, connected, rssi)
  local now = getTime()
  local repeatSec = wgt.options.AlarmSec or 10
  local repeatTicks = math.max(0, repeatSec) * 100
  local soundPath = getAlarmSoundPath(wgt, level)

  if level < 0 or soundPath == nil then
    wgt.lastAlarmLevel = -1
    return level
  end

  if wgt.lastAlarmLevel ~= level then
    playFile(soundPath)
    wgt.lastAlarmTick = now
    wgt.lastAlarmLevel = level
    return level
  end

  if repeatTicks == 0 then
    return level
  end

  if (now - (wgt.lastAlarmTick or 0)) >= repeatTicks then
    playFile(soundPath)
    wgt.lastAlarmTick = now
    wgt.lastAlarmLevel = level
  end

  return level
end

local function drawCommon(wgt, titleFlags, valueFlags, small)
  local x = wgt.zone.x
  local y = wgt.zone.y
  local w = wgt.zone.w
  local h = wgt.zone.h

  local raw, us, connected, rssi = decodeLinkData(wgt)
  local bg = getBgColor(wgt, connected, rssi)
  local level = handleAlarm(wgt, connected, rssi)

  lcd.setColor(CUSTOM_COLOR, bg)
  lcd.drawFilledRectangle(x, y, w, h, CUSTOM_COLOR)
  lcd.setColor(CUSTOM_COLOR, BLACK)
  lcd.drawRectangle(x, y, w, h, CUSTOM_COLOR)

  lcd.setColor(CUSTOM_COLOR, wgt.options.TextColor)

  if small then
    lcd.drawText(x + 4, y + 1, "RSSI", SMLSIZE + BLACK + SHADOWED)
    if connected and rssi ~= nil then
      lcd.drawText(x + 4, y + 14, string.format("%d", rssi), MIDSIZE + CUSTOM_COLOR + SHADOWED)
      lcd.drawText(x + 40, y + 18, "dBm", SMLSIZE + CUSTOM_COLOR + SHADOWED)
    else
      lcd.drawText(x + 4, y + 14, "---", MIDSIZE + CUSTOM_COLOR + SHADOWED)
    end
  else
    lcd.drawText(x + 6, y + 4, "ESPNOW RSSI", titleFlags + BLACK + SHADOWED)
    if connected and rssi ~= nil then
      lcd.drawText(x + 6, y + 28, string.format("%d dBm", rssi), valueFlags + CUSTOM_COLOR + SHADOWED)
    else
      lcd.drawText(x + 6, y + 28, "---", valueFlags + CUSTOM_COLOR + SHADOWED)
    end
    lcd.drawText(x + 110, y + h - 50, string.format("RAW=%d", raw), SMLSIZE + CUSTOM_COLOR + SHADOWED)
    lcd.drawText(x + 110, y + h - 38, string.format("US=%d", us), SMLSIZE + CUSTOM_COLOR + SHADOWED)
    lcd.drawText(x + 110, y + h - 26, string.format("ALR:%s", getLevelLabel(level)), SMLSIZE + CUSTOM_COLOR + SHADOWED)
  end
end

local function refreshZoneTiny(wgt)
  drawCommon(wgt, SMLSIZE, DBLSIZE, true)
end

local function refreshZoneSmall(wgt)
  drawCommon(wgt, SMLSIZE, SMLSIZE, false)
end

local function refreshZoneMedium(wgt)
  drawCommon(wgt, MIDSIZE, MIDSIZE, false)
end

local function refreshZoneLarge(wgt)
  drawCommon(wgt, MIDSIZE, XLSIZE, false)
end

local function refreshZoneXLarge(wgt)
  drawCommon(wgt, MIDSIZE, XXLSIZE, false)
end

function refresh(wgt)
  if wgt == nil or wgt.options == nil then
    return
  end

  if     wgt.zone.w > 380 and wgt.zone.h > 165 then refreshZoneXLarge(wgt)
  elseif wgt.zone.w > 180 and wgt.zone.h > 145 then refreshZoneLarge(wgt)
  elseif wgt.zone.w > 170 and wgt.zone.h >  65 then refreshZoneMedium(wgt)
  elseif wgt.zone.w > 150 and wgt.zone.h >  28 then refreshZoneSmall(wgt)
  elseif wgt.zone.w >  65 and wgt.zone.h >  35 then refreshZoneTiny(wgt)
  end

  lcd.setColor(CUSTOM_COLOR, BLACK)
end

return {
  name = "EspNow",
  options = options,
  create = create,
  update = update,
  background = background,
  refresh = refresh
}
