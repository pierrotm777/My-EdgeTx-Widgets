---- #########################################################################
---- #Armed                       #
---- #                                                                       #
---- #########################################################################

local Bitmaps30 = {}
local Bitmaps40 = {}
local valeurs = 0
-----local canalgaz = 'ch3'  ---  <----A CHANGER SI AUTRE CANAL UTILISE

local options = {
  { "TextColor", COLOR, RED },
  { "LS_SAFE", SOURCE,0},
  { "Invert", BOOL, 0},
  { "canal_GZ", SOURCE,0},
}

local function create(zone, options)
  local wgt  = { zone=zone, options=options}
   return wgt
end

local function update(wgt, options)
  if (wgt==nil) then
    print("update(nil)")
    return
  end
  wgt.options = options
end

local function background(wgt)
  return
end

------------------------------------------------------------

local function getArmedStatus(wgt)
  local value = getValue(wgt.options.LS_SAFE)

 if wgt.options.Invert == 1 then
    value = -value
  end
  

  if value > -10 then
    return true
  else
    return false
  end
end

-- This size is for top bar wgts
local function refreshZoneTiny(wgt)
  local status = getArmedStatus(wgt)
  local percent = string.format("%u",((getValue(wgt.options.canal_GZ)+1024)/2048)*100)
 -- local value = getValue(wgt.options.Source)
 
  if Bitmaps30[0] == nil then
    Bitmaps30[0] = Bitmap.open("/WIDGETS/Armed_JP/Mt_OFF.png")
    Bitmaps30[1] = Bitmap.open("/WIDGETS/Armed_JP/Mt_ON.png")
  end
 
  if status == true then
    lcd.drawText(wgt.zone.x + 44, wgt.zone.y + -5, " %" , MIDSIZE + CUSTOM_COLOR)
	lcd.drawText(wgt.zone.x + 30, wgt.zone.y + 17, ""..percent , MIDSIZE + CUSTOM_COLOR)
    lcd.drawBitmap(Bitmaps30[1], wgt.zone.x -10,wgt.zone.y )
  else
    lcd.drawBitmap(Bitmaps30[0], wgt.zone.x ,wgt.zone.y )
  end
end

--- Size is 160x32 1/8th
local function refreshZoneSmall(wgt)
  
end

--- Size is 225x98 1/4th  (no sliders/trim)
local function refreshZoneMedium(wgt)
  
end

--- Size is 192x152 1/2
local function refreshZoneLarge(wgt)

end

--- Size is 390x172 1/1
--- Size is 460x252 1/1 (no sliders/trim/topbar)
local function refreshZoneXLarge(wgt)

end


function refresh(wgt)

  if (wgt==nil) then
    print("refresh(nil)")
    return
  end

  if (wgt.options==nil) then
    print("refresh(wgt.options=nil)")
    return
  end

  lcd.setColor(CUSTOM_COLOR, wgt.options.TextColor)

  if     wgt.zone.w  > 380 and wgt.zone.h > 165 then refreshZoneXLarge(wgt)
  elseif wgt.zone.w  > 180 and wgt.zone.h > 145 then refreshZoneLarge(wgt)
  elseif wgt.zone.w  > 170 and wgt.zone.h >  65 then refreshZoneMedium(wgt)
  elseif wgt.zone.w  > 150 and wgt.zone.h >  28 then refreshZoneSmall(wgt)
  elseif wgt.zone.w  >  65 and wgt.zone.h >  35 then refreshZoneTiny(wgt)
  end
   --lcd.setColor(TEXT_COLOR, BLACK) 
   lcd.setColor(CUSTOM_COLOR, BLACK)
end

return { name="Armed_JP", options=options, create=create, update=update, background=background, refresh=refresh }
